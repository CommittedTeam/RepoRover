# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['reporover']

package_data = \
{'': ['*']}

install_requires = \
['PyDriller>=1.15.5,<2.0.0',
 'PyGithub>=1.55,<2.0',
 'giturlparse>=0.10.0,<0.11.0',
 'pandas>=1.2.4,<2.0.0',
 'pyarrow>=4.0.0,<5.0.0',
 'typer>=0.3.2,<0.4.0']

setup_kwargs = {
    'name': 'reporover',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1',
}


setup(**setup_kwargs)
